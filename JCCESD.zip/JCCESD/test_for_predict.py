# ==========================================================================
#    This UWOC-JCCESD code is used for the joint channel classification
#    and estimation with signal detection (JCCESD) scheme in
#    underwater wireless optical communication (UWOC) systems.
#
#    Copyright (C) <2020>  <Huaiyin Lu>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    If you use and/or modify this program for further researches and/or
#    applications, please cite the reference paper as follows, which proposes
#    the JCCESD scheme.
#
#    H. Lu, M. Jiang, and J. Cheng, ``Deep learning aided robust joint channel
#    classification, channel estimation, and signal detection for underwater
#    optical communication'', IEEE Trans. Commun., 2020.
#    BibTex: @ARTICLE{Lu2020j-UWOC-JCCESD,
#    Title={{Deep learning aided robust joint channel classification, channel estimation, and signal detection for underwater optical communication}},
#    Author={H. Lu and M. Jiang and J. Cheng},
#    Journal={{IEEE Trans. Commun.}},
#    Year={2020}
#    }
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
#    Author: Huaiyin Lu
#    Affiliation: Sun Yat-sen University, Guangzhou, China
#    Version: 0.1
#    Upload date: Dec. 07, 2020
#    E-mail: 513284310@qq.com
# ==========================================================================

# This file is the procedure of generating \mathbf{\tilde{Q}}_1 to \mathbf{\tilde{Q}}_4 reflecting to Section III-C.4.

import numpy as np
import pandas as pd
from keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint, TensorBoard
from keras import *
import copy
import h5py
import warnings
warnings.filterwarnings("ignore")
import params

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "2"


#DNN weight path
weight = 'weights/DNN_detector_type3.hdf5'

#data set path
my_dir1 = 'data/test_'


for my_db in range(6):
    file_name = '{}db'.format(20 + my_db * 10)  # different testing set
    epochs = params.max_epochs
    batch_size = params.batch_size

    my_dir2 = file_name +'_input_mix_type.csv'
    my_dir=my_dir1+my_dir2

    # load testing set
    test_0db_input = pd.read_csv(my_dir)
    test = test_0db_input.values[:,1:]
    test = np.expand_dims(test, axis=2)

    # load model and weights
    model = params.model_factory()
    model.load_weights(filepath=weight)

    # predict
    predict = model.predict(test)


    # save the prediction
    df = pd.DataFrame(predict)
    df.to_csv('data/perdict_'+'{}_test_output_'.format(file_name)+'detector_type3.csv',index=False)

