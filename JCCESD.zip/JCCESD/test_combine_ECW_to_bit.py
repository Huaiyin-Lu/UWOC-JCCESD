# ==========================================================================
#    This UWOC-JCCESD code is used for the joint channel classification
#    and estimation with signal detection (JCCESD) scheme in
#    underwater wireless optical communication (UWOC) systems.
#
#    Copyright (C) <2020>  <Huaiyin Lu>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    If you use and/or modify this program for further researches and/or
#    applications, please cite the reference paper as follows, which proposes
#    the JCCESD scheme.
#
#    H. Lu, M. Jiang, and J. Cheng, ``Deep learning aided robust joint channel
#    classification, channel estimation, and signal detection for underwater
#    optical communication'', IEEE Trans. Commun., 2020.
#    BibTex: @ARTICLE{Lu2020j-UWOC-JCCESD,
#    Title={{Deep learning aided robust joint channel classification, channel estimation, and signal detection for underwater optical communication}},
#    Author={H. Lu and M. Jiang and J. Cheng},
#    Journal={{IEEE Trans. Commun.}},
#    Year={2020}
#    }
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
#    Author: Huaiyin Lu
#    Affiliation: Sun Yat-sen University, Guangzhou, China
#    Version: 0.1
#    Upload date: Dec. 07, 2020
#    E-mail: 513284310@qq.com
# ==========================================================================

# This file is the procedure of testing JCCESD with ECW, DNN detectors and testing data sets.

import numpy as np
import pandas as pd
from keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint, TensorBoard
#from sklearn.model_selection import train_test_split
from keras import *
import copy
import h5py
import warnings
warnings.filterwarnings("ignore")
import params
import keras.backend as K

epochs = params.max_epochs
batch_size = params.batch_size
# detector weights path
weight1 = 'weights/'+'type_1'+'.hdf5'
weight2 = 'weights/'+'type_2'+'.hdf5'
weight3 = 'weights/'+'type_3'+'.hdf5'
weight4 = 'weights/'+'type_4'+'.hdf5'

# testing data set path
my_dir = 'data/0.1/'
my_dir2 = '_type3.csv'

# ouput BER path
my_dir3 = '_type3_mix.csv'

ECW_dir = 'ECW/ECW_type3_weight.csv'


import os
os.environ["CUDA_VISIBLE_DEVICES"] = "3"


pro_vector_read = pd.read_csv(ECW_dir)
pro_vector = pro_vector_read.values[:,0:]

loss_vector=np.ones((1,51))


for my_db in range(51):
    file_name = '{}db'.format(20 + my_db)

    # load testing set
    test_0db_input = pd.read_csv(my_dir + 'test_{}_input'.format(file_name) + my_dir2)
    test = test_0db_input.values[:,1:]
    test = np.expand_dims(test, axis=2)
    test_0db_output = pd.read_csv(my_dir + 'test_{}_output'.format(file_name) + my_dir2)
    test_output = test_0db_output.values[:,1:]

    # load model and weights1
    model = params.model_factory()

    # predict1
    model.load_weights(filepath=weight1)
    predict1 = model.predict(test)

    # predict2
    model.load_weights(filepath=weight2)
    predict2 = model.predict(test)

    # predict3
    model.load_weights(filepath=weight3)
    predict3 = model.predict(test)

    # predict4
    model.load_weights(filepath=weight4)
    predict4 = model.predict(test)


################################################linear##################################################################

    pro = pro_vector[0,:]

    #linear
    predict = predict1*pro[0]+predict2*pro[1]+predict3*pro[2]+predict4*pro[3]
    predict[predict >= 0.5] = 1
    predict[predict < 0.5] = 0
    # compute the loss
    loss1 = sum(((test_output - predict)**2.).sum(axis=0)/len(predict)/len(predict[0]))
    loss_vector[0,my_db]=loss1

df = pd.DataFrame(loss_vector)
df.to_csv('BER/BER_classify'+my_dir3 , index=False)
